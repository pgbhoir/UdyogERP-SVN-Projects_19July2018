declare @new_range numeric

IF NOT EXISTS(SELECT [PadName],[BarName] FROM Com_Menu WHERE PadName = 'SETTINGS' AND BarName = 'MASTERSETTINGS')
BEGIN 
	execute [USP_Chk_ComMenuRange] 0,@rrange= @new_range output print @new_range

	INSERT INTO Com_Menu([RANGE],[PADNAME],[PADNUM],[BARNAME],[BARNUM],[PROMPNAME],[NUMITEM],[HOTKEY],[PROGNAME],[E_],[N_],[R_],[T_],[I_],[O_],[B_],[X_],[MENUTYPE],[ISACTIVE],[PUSER],[MDEFAULT],[LABKEY],[SKIPFOR],[CPROG],[MARK],[XTVS_],[DSNI_],[MCUR_],[TDS_]) 
	VALUES ( @new_range,'SETTINGS',0,'MASTERSETTINGS',6,'Master Setting',0,'','DO UEMASTSET WITH "^'+CAST(@new_range AS VARCHAR)+'"',0,0,0,0,0,0,0,0,'General',0,'Master Setting',0,'','','',0,0,0,0,0) 
END


IF NOT EXISTS(SELECT [PadName],[BarName] FROM Com_Menu WHERE PadName = 'UTILITIES' AND BarName = 'MULTIAPPROVAL')
BEGIN
	execute [USP_Chk_ComMenuRange] 0,@rrange= @new_range output print @new_range

	INSERT INTO com_menu([range], [padname], [padnum], [barname], [barnum], [prompname], [numitem], [hotkey], [progname], [E_], [n_], [r_], [t_], [i_], [o_], [b_], [x_], [Menutype], [Isactive], [puser], [mdefault], [labkey], [skipfor], [cprog], [mark], [xtvs_], [dsni_], [mcur_], [tds_], [newrange], [HRPay_]) 
	VALUES (@new_range, 'UTILITIES', 0, 'MULTIAPPROVAL', 11, 'Multi Level Approval', 3, '', '', null, null, null, null, null, null, null, null, 'General', null, 'Multi Level Approval', null, null, null, null, null, null, null, null, 0, null, 0)

END

IF NOT EXISTS(SELECT [PadName],[BarName] FROM Com_Menu WHERE PadName = 'MULTIAPPROVAL' AND BarName = 'WORKFLOWMASTER')
BEGIN
	execute [USP_Chk_ComMenuRange] 0,@rrange= @new_range output print @new_range
	
	INSERT INTO COM_menu([range], [padname], [padnum], [barname], [barnum], [prompname], [numitem], [hotkey], [progname], [E_], [n_], [r_], [t_], [i_], [o_], [b_], [x_], [Menutype], [Isactive], [puser], [mdefault], [labkey], [skipfor], [cprog], [mark], [xtvs_], [dsni_], [mcur_], [tds_], [newrange], [HRPay_]) 
	VALUES (@new_range, 'MULTIAPPROVAL', 0, 'WORKFLOWMASTER', 1, 'Workflow Master', 0, '', 'DO UDCALLEXTPROG.APP WITH "MLA.APPS.EXE","M","^'+CAST(@new_range AS VARCHAR)+'"', null, null, null, null, null, null, null, null, 'General', null, 'Workflow Master', null, null, null, null, null, null, null, null, 0, null, 0)
END

IF NOT EXISTS(SELECT [PadName],[BarName] FROM Com_Menu WHERE PadName = 'MULTIAPPROVAL' AND BarName = 'EMAILSETTING')
BEGIN
	execute [USP_Chk_ComMenuRange] 0,@rrange= @new_range output print @new_range
	
	INSERT INTO COM_menu([range], [padname], [padnum], [barname], [barnum], [prompname], [numitem], [hotkey], [progname], [E_], [n_], [r_], [t_], [i_], [o_], [b_], [x_], [Menutype], [Isactive], [puser], [mdefault], [labkey], [skipfor], [cprog], [mark], [xtvs_], [dsni_], [mcur_], [tds_], [newrange], [HRPay_]) 
	VALUES (@new_range, 'MULTIAPPROVAL', 0, 'EMAILSETTING', 3, 'Email Setting', 0, '', 'DO UDCALLEXTPROG.APP WITH "MLA.APPS.EXE","S","^'+CAST(@new_range AS VARCHAR)+'"', null, null, null, null, null, null, null, null, 'General', null, 'Email Setting', null, null, null, null, null, null, null, null, 0, null, 0)
END

IF NOT EXISTS(SELECT [PadName],[BarName] FROM Com_Menu WHERE PadName = 'MULTIAPPROVAL' AND BarName = 'APPROVALWORKFLOW')
BEGIN 
	execute [USP_Chk_ComMenuRange] 0,@rrange= @new_range output print @new_range
	
	INSERT INTO COM_menu([range], [padname], [padnum], [barname], [barnum], [prompname], [numitem], [hotkey], [progname], [E_], [n_], [r_], [t_], [i_], [o_], [b_], [x_], [Menutype], [Isactive], [puser], [mdefault], [labkey], [skipfor], [cprog], [mark], [xtvs_], [dsni_], [mcur_], [tds_], [newrange], [HRPay_]) 
	VALUES (@new_range, 'MULTIAPPROVAL', 0, 'APPROVALWORKFLOW', 2, 'Approval Workflow', 0, '', 'DO UDCALLEXTPROG.APP WITH "MLA.APPS.EXE","T", COMPANY.STA_DT,COMPANY.END_DT,SET("PATH"),APATH,"^'+CAST(@new_range AS VARCHAR)+'"', null, null, null, null, null, null, null, null, 'General', null, 'Approval Workflow', null, null, null, null, null, null, null, null, 0, null, 0)
END
