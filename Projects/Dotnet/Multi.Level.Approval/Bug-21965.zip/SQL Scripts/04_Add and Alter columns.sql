Execute Add_Columns 'mastcode','apgenps bit default 0 with values'
Execute Add_Columns 'mastcode','applevel int default 0 with values'
Execute Add_Columns 'mastcode','appmailsub Varchar(150) default '''' with values'
Execute Add_Columns 'mastcode','applevel_init bit default 0 with values'

update mastcode set BC_avail = 1 where [code] = 'AM'

Execute Add_Columns 'ac_mast','apgen Varchar(10) default '''' with values'
Execute Add_Columns 'ac_mast','apgenby Varchar(15) default '''' with values'
Execute Add_Columns 'ac_mast','Apgentime Varchar(20) default '''' with values'
Execute Add_Columns 'ac_mast','U_remarks Varchar(200) default '''' with values'

Execute Add_Columns 'it_mast','apgen Varchar(10) default '''' with values'
Execute Add_Columns 'it_mast','apgenby Varchar(15) default '''' with values'
Execute Add_Columns 'it_mast','Apgentime Varchar(20) default '''' with values'
Execute Add_Columns 'it_mast','U_remarks Varchar(200) default '''' with values'
	
Execute Add_Columns 'Lcode','applevel int default 0 with values'
Execute Add_Columns 'Lcode','Headfilt Varchar(1000) default '''' with values'
Execute Add_Columns 'Lcode','Detfilt Varchar(1000) default '''' with values'
Execute Add_Columns 'Lcode','appmailsub Varchar(150) default '''' with values'
Execute Add_Columns 'Lcode','applevel_init bit default 0 with values'

