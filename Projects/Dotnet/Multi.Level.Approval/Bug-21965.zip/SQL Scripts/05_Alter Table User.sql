USE [Vudyog]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

If not exists (select * from syscolumns where id = object_id('user') and [name] = 'user_desig' )
Begin
	Alter table [User] add user_desig varchar(150) default '' with values
End

If not exists (select * from syscolumns where id = object_id('user') and [name] = 'user_email' )
Begin
	Alter table [User] add user_email varchar(150) default '' with values
End

If not exists (select * from syscolumns where id = object_id('user') and [name] = 'user_dept' )
Begin
	Alter table [User] add user_dept varchar(150) default '' with values
End

If not exists (select * from syscolumns where id = object_id('user') and [name] = 'remarks' )
Begin
	Alter table [User] add remarks varchar(200) default '' with values
End

